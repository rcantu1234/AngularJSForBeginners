var MyApp;
(function (MyApp) {
    var Controllers;
    (function (Controllers) {
        var apiURL = '/api/cars/search/';
        var HomeController = (function () {
            function HomeController() {
            }
            return HomeController;
        }());
        Controllers.HomeController = HomeController;
        angular.module('MyApp').controller('HomeController', HomeController);
        var DetailsController = (function () {
            function DetailsController(id, $uibModalInstance, $http) {
                var _this = this;
                this.id = id;
                this.$uibModalInstance = $uibModalInstance;
                this.$http = $http;
                var url = "/api/cars/" + this.id;
                this.$http.get(url)
                    .then(function (response) {
                    _this.car = response.data;
                })
                    .catch(function (response) {
                    console.error('Could not retrieve cars.');
                });
            }
            DetailsController.prototype.ok = function () {
                this.$uibModalInstance.close();
            };
            return DetailsController;
        }());
        Controllers.DetailsController = DetailsController;
        angular.module('MyApp').controller('DetailsController', DetailsController);
        var DialogController = (function () {
            function DialogController(carName, $uibModalInstance) {
                this.carName = carName;
                this.$uibModalInstance = $uibModalInstance;
            }
            DialogController.prototype.ok = function () {
                this.$uibModalInstance.close();
            };
            return DialogController;
        }());
        Controllers.DialogController = DialogController;
        angular.module('MyApp').controller('DialogController', DialogController);
        var makesURL = '/api/makes/';
        var MakesController = (function () {
            function MakesController($http) {
                var _this = this;
                this.$http = $http;
                this.$http.get('api/makes')
                    .then(function (response) {
                    _this.makes = response.data;
                }).catch(function (response) {
                    console.error('Could not retrieve makes.');
                });
            }
            return MakesController;
        }());
        Controllers.MakesController = MakesController;
        angular.module('MyApp').controller('MakesController', MakesController);
        var SearchController = (function () {
            function SearchController($http, $stateParams, $uibModal) {
                this.$http = $http;
                this.$uibModal = $uibModal;
            }
            SearchController.prototype.fetch = function () {
                var _this = this;
                if (this.search) {
                    console.log('searching');
                    this.$http.get(apiURL + this.search)
                        .then(function (results) {
                        _this.cars = results.data;
                    });
                }
                else {
                    this.cars = " ";
                }
            };
            SearchController.prototype.showModal = function (id) {
                this.$uibModal.open({
                    templateUrl: '/templates/details.html',
                    controller: 'DetailsController',
                    controllerAs: 'modal',
                    resolve: {
                        id: function () { return id; }
                    },
                    size: 'lg'
                });
            };
            return SearchController;
        }());
        Controllers.SearchController = SearchController;
        angular.module('MyApp').controller('SearchController', SearchController);
        var ShowController = (function () {
            function ShowController($http, $stateParams, $uibModal) {
                var _this = this;
                this.$http = $http;
                this.$uibModal = $uibModal;
                this.$http.get('api/cars')
                    .then(function (response) {
                    var temp = response.data;
                    _this.paramId = $stateParams['id'];
                    _this.cars = temp.filter(function (car) {
                        return car.CarMakeId == $stateParams['id'];
                    });
                }).catch(function (response) {
                    console.error('Could not retrieve cars.');
                });
            }
            ShowController.prototype.showModal = function (id) {
                this.$uibModal.open({
                    templateUrl: '/templates/details.html',
                    controller: 'DetailsController',
                    controllerAs: 'modal',
                    resolve: {
                        id: function () { return id; }
                    },
                    size: 'lg'
                });
            };
            return ShowController;
        }());
        Controllers.ShowController = ShowController;
    })(Controllers = MyApp.Controllers || (MyApp.Controllers = {}));
})(MyApp || (MyApp = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udHJvbGxlcnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb250cm9sbGVycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxJQUFVLEtBQUssQ0FzSGQ7QUF0SEQsV0FBVSxLQUFLO0lBQUMsSUFBQSxXQUFXLENBc0gxQjtJQXRIZSxXQUFBLFdBQVcsRUFBQyxDQUFDO1FBRXpCLElBQU0sTUFBTSxHQUFHLG1CQUFtQixDQUFDO1FBRW5DO1lBQUE7WUFFQSxDQUFDO1lBQUQscUJBQUM7UUFBRCxDQUFDLEFBRkQsSUFFQztRQUZZLDBCQUFjLGlCQUUxQixDQUFBO1FBQ0QsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFFckU7WUFRSSwyQkFBbUIsRUFBVSxFQUFVLGlCQUE2RCxFQUFVLEtBQXNCO2dCQVJ4SSxpQkFrQkQ7Z0JBVndCLE9BQUUsR0FBRixFQUFFLENBQVE7Z0JBQVUsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUE0QztnQkFBVSxVQUFLLEdBQUwsS0FBSyxDQUFpQjtnQkFDekksSUFBSSxHQUFHLEdBQUcsWUFBWSxHQUFFLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztxQkFDUixJQUFJLENBQUMsVUFBQyxRQUFRO29CQUNYLEtBQUksQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztnQkFDN0IsQ0FBQyxDQUFDO3FCQUNELEtBQUssQ0FBQyxVQUFDLFFBQVE7b0JBQ1osT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO2dCQUM5QyxDQUFDLENBQUMsQ0FBQztZQUNqQixDQUFDO1lBYlksOEJBQUUsR0FBVDtnQkFDSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbkMsQ0FBQztZQVlQLHdCQUFDO1FBQUQsQ0FBQyxBQWxCQyxJQWtCRDtRQWxCYyw2QkFBaUIsb0JBa0IvQixDQUFBO1FBRUQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUV2RTtZQU1BLDBCQUFtQixPQUFlLEVBQVUsaUJBQTZEO2dCQUF0RixZQUFPLEdBQVAsT0FBTyxDQUFRO2dCQUFVLHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBNEM7WUFBSSxDQUFDO1lBSnZHLDZCQUFFLEdBQVQ7Z0JBQ0csSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2xDLENBQUM7WUFHTCx1QkFBQztRQUFELENBQUMsQUFQRyxJQU9IO1FBUGdCLDRCQUFnQixtQkFPaEMsQ0FBQTtRQUNELE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsVUFBVSxDQUFDLGtCQUFrQixFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFFdkUsSUFBTSxRQUFRLEdBQUcsYUFBYSxDQUFDO1FBQy9CO1lBR0kseUJBQW9CLEtBQXNCO2dCQUg5QyxpQkFXQztnQkFSdUIsVUFBSyxHQUFMLEtBQUssQ0FBaUI7Z0JBQ3hDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztxQkFDeEIsSUFBSSxDQUFDLFVBQUMsUUFBUTtvQkFDYixLQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0JBQzdCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFDLFFBQVE7b0JBQ2hCLE9BQU8sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLENBQUMsQ0FBQztnQkFDN0MsQ0FBQyxDQUFDLENBQUE7WUFDTixDQUFDO1lBQ0wsc0JBQUM7UUFBRCxDQUFDLEFBWEQsSUFXQztRQVhZLDJCQUFlLGtCQVczQixDQUFBO1FBQ0QsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFdkU7WUE0QkUsMEJBQW9CLEtBQXNCLEVBQUUsWUFBdUMsRUFBVSxTQUE2QztnQkFBdEgsVUFBSyxHQUFMLEtBQUssQ0FBaUI7Z0JBQW1ELGNBQVMsR0FBVCxTQUFTLENBQW9DO1lBQUksQ0FBQztZQXZCL0ksZ0NBQUssR0FBTDtnQkFBQSxpQkFVQztnQkFURyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztvQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUN6QixJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQzt5QkFDL0IsSUFBSSxDQUFDLFVBQUMsT0FBTzt3QkFDVixLQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUM7b0JBQzdCLENBQUMsQ0FBQyxDQUFDO2dCQUNYLENBQUM7Z0JBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ04sSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLENBQUM7WUFDTCxDQUFDO1lBRU0sb0NBQVMsR0FBaEIsVUFBaUIsRUFBVTtnQkFDakIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7b0JBQ2hCLFdBQVcsRUFBRSx5QkFBeUI7b0JBQ3RDLFVBQVUsRUFBRSxtQkFBbUI7b0JBQy9CLFlBQVksRUFBRSxPQUFPO29CQUNyQixPQUFPLEVBQUU7d0JBQ0wsRUFBRSxFQUFFLGNBQU0sT0FBQSxFQUFFLEVBQUYsQ0FBRTtxQkFDZjtvQkFDRCxJQUFJLEVBQUUsSUFBSTtpQkFDYixDQUFDLENBQUM7WUFDYixDQUFDO1lBRUgsdUJBQUM7UUFBRCxDQUFDLEFBN0JELElBNkJDO1FBN0JZLDRCQUFnQixtQkE2QjVCLENBQUE7UUFDRCxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXpFO1lBSUUsd0JBQW9CLEtBQXNCLEVBQUUsWUFBdUMsRUFBVSxTQUE2QztnQkFKNUksaUJBNkJDO2dCQXpCcUIsVUFBSyxHQUFMLEtBQUssQ0FBaUI7Z0JBQW1ELGNBQVMsR0FBVCxTQUFTLENBQW9DO2dCQUV4SSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7cUJBQ3ZCLElBQUksQ0FBQyxVQUFDLFFBQVE7b0JBQ2IsSUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztvQkFDekIsS0FBSSxDQUFDLE9BQU8sR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ2xDLEtBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFDLEdBQUc7d0JBQzFCLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDN0MsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUMsUUFBUTtvQkFDaEIsT0FBTyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO2dCQUM1QyxDQUFDLENBQUMsQ0FBQTtZQUNOLENBQUM7WUFFTSxrQ0FBUyxHQUFoQixVQUFpQixFQUFVO2dCQUNqQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztvQkFDaEIsV0FBVyxFQUFFLHlCQUF5QjtvQkFDdEMsVUFBVSxFQUFFLG1CQUFtQjtvQkFDL0IsWUFBWSxFQUFFLE9BQU87b0JBQ3JCLE9BQU8sRUFBRTt3QkFDTCxFQUFFLEVBQUUsY0FBTSxPQUFBLEVBQUUsRUFBRixDQUFFO3FCQUNmO29CQUNELElBQUksRUFBRSxJQUFJO2lCQUNiLENBQUMsQ0FBQztZQUNiLENBQUM7WUFDSCxxQkFBQztRQUFELENBQUMsQUE3QkQsSUE2QkM7UUE3QlksMEJBQWMsaUJBNkIxQixDQUFBO0lBQ0wsQ0FBQyxFQXRIZSxXQUFXLEdBQVgsaUJBQVcsS0FBWCxpQkFBVyxRQXNIMUI7QUFBRCxDQUFDLEVBdEhTLEtBQUssS0FBTCxLQUFLLFFBc0hkIn0=