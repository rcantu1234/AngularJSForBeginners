'use strict';
var MyApp;
(function (MyApp) {
    angular.module('MyApp', ['ui.router', 'ngResource', 'ui.bootstrap', 'ngAnimate'])
        .config(function ($stateProvider, $locationProvider, $urlRouterProvider) {
        $stateProvider.state('Home', {
            url: '/',
            templateUrl: '/templates/home.html',
            controller: MyApp.Controllers.HomeController,
            controllerAs: 'controller'
        }).state('About', {
            url: '/about',
            templateUrl: '/templates/about.html',
            controller: MyApp.Controllers.MakesController,
            controllerAs: 'controller'
        }).state('Details', {
            url: '/details',
            templateUrl: '/templates/details.html',
            controller: MyApp.Controllers.DetailsController,
            controllerAs: 'controller'
        }).state('Show', {
            url: '/show:id',
            templateUrl: '/templates/show.html',
            controller: MyApp.Controllers.ShowController,
            controllerAs: 'controller'
        }).state('Search', {
            url: '/search:id',
            templateUrl: '/templates/search.html',
            controller: MyApp.Controllers.SearchController,
            controllerAs: 'controller'
        });
        $urlRouterProvider.otherwise('/');
    });
})(MyApp || (MyApp = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXBwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFlBQVksQ0FBQztBQUNiLElBQVUsS0FBSyxDQXFDZDtBQXJDRCxXQUFVLEtBQUssRUFBQyxDQUFDO0lBQ2YsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxXQUFXLENBQUMsQ0FBQztTQUM5RSxNQUFNLENBQUMsVUFDUixjQUFvQyxFQUNwQyxpQkFBdUMsRUFDdkMsa0JBQTRDO1FBRTVDLGNBQWMsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFO1lBQzNCLEdBQUcsRUFBRSxHQUFHO1lBQ1IsV0FBVyxFQUFFLHNCQUFzQjtZQUNuQyxVQUFVLEVBQUUsS0FBSyxDQUFDLFdBQVcsQ0FBQyxjQUFjO1lBQzVDLFlBQVksRUFBRSxZQUFZO1NBQzNCLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFO1lBQ2hCLEdBQUcsRUFBRSxRQUFRO1lBQ2IsV0FBVyxFQUFFLHVCQUF1QjtZQUNwQyxVQUFVLEVBQUUsS0FBSyxDQUFDLFdBQVcsQ0FBQyxlQUFlO1lBQzdDLFlBQVksRUFBRSxZQUFZO1NBQzNCLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFO1lBQ2xCLEdBQUcsRUFBRSxVQUFVO1lBQ2YsV0FBVyxFQUFFLHlCQUF5QjtZQUN0QyxVQUFVLEVBQUUsS0FBSyxDQUFDLFdBQVcsQ0FBQyxpQkFBaUI7WUFDL0MsWUFBWSxFQUFFLFlBQVk7U0FDM0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUU7WUFDZixHQUFHLEVBQUUsVUFBVTtZQUNmLFdBQVcsRUFBRSxzQkFBc0I7WUFDbkMsVUFBVSxFQUFFLEtBQUssQ0FBQyxXQUFXLENBQUMsY0FBYztZQUM1QyxZQUFZLEVBQUUsWUFBWTtTQUMzQixDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRTtZQUNqQixHQUFHLEVBQUUsWUFBWTtZQUNqQixXQUFXLEVBQUUsd0JBQXdCO1lBQ3JDLFVBQVUsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLGdCQUFnQjtZQUM5QyxZQUFZLEVBQUUsWUFBWTtTQUMzQixDQUFDLENBQUM7UUFFSCxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7SUFFcEMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLEVBckNTLEtBQUssS0FBTCxLQUFLLFFBcUNkIn0=